#ifndef _ZIA_H_
#define _ZIA_H_

//declaring functions will be used

int part1(int, int);

int part2(int, int);

int part3(int, int);

int part4(int);


#endif /* _ZIA_H_ */
