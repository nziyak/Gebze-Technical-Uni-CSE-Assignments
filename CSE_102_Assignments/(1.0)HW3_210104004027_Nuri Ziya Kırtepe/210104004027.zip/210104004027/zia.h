#ifndef _ZIA_H_
#define _ZIA_H_

//declaring functions will be used

void game(int);


void drawroom(void);


void gplay(int, int, int, int, int);


int status(int); 


#endif /* _ZIA_H_ */
