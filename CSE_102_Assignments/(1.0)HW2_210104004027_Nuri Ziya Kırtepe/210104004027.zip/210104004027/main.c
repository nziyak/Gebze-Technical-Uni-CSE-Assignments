#include <stdio.h>
#include <math.h>
#include "zia.h"

int main()
{
  
  /*int year;
  int ex1, ex2, ex3, ass1, ass2;
  
  printf("please enter a year: ");
  scanf("%d", &year);
  
  leapy(year);
  
  printf("------------------------------------------------------------\n\n");
  */
  //---------- end of the part1 ----------//
  
  char forsel; //format selection variable
  
  printf("Welcome to the Enhanced Calculator!\n\nEnter the format of output (Scientific/Integer)-->(S/I): ");
  scanf("%c", &forsel);
  
  if((forsel != 's' && forsel != 'S') && (forsel != 'i' && forsel != 'I')) //if user enters anything different S,s, I and i, print invalid format.
  {
     printf("Invalid format.");
  }
  
  calc(forsel);
  
  printf("------------------------------------------------------------\n\n");
  
  //---------- end of the part2 ----------// 
  
 /* printf("enter 3 exam grades of student: ");
  scanf("%d %d %d", &ex1, &ex2, &ex3);
  
  printf("enter 2 assignment grades of student: ");  
  scanf("%d %d", &ass1, &ass2);
  
  fincalc(ex1, ex2, ex3, ass1, ass2);
  
  //---------- end of the part3 ----------//
  
  */
  return 0;

}
