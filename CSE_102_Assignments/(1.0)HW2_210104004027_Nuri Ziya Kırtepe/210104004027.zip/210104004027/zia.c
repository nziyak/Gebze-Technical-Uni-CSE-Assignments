#include <stdio.h>
#include <math.h>
#include "zia.h"

int leapy(int year)
{
   
    if(year % 4 == 0)
    {
      
       
       if(year % 4000 == 0 || (year % 100 == 0  &&  year % 400 != 0))
       { 
             printf("%d is not a leap year.\n\n", year);
       }
              
       else
       {
             printf("%d is a leap year.\n\n", year);
       }              
           
               
    }   
      
    else
    {
         printf("%d is not a leap year.\n\n", year);
    }

}

// i wrote my code according to the detailed definition of vikipedia of leap year. you can access that infos through this link: https://tr.wikipedia.org/wiki/Art%C4%B1k_y%C4%B1l



double calc(char forsel)
{
    
    char op; //operator
    int m, n, numi1, numi2, numti; //m, n, first and second integer operands, temporary integer variable
    double numd1, numd2, numtd, result; //first and second double operands, temporary double variable, result
    
    
    if(forsel == 'S' || forsel == 's') //adding lowercase to possibility of users enter in lowercase
    {
         printf("Enter m and n values(n can not be bigger than m!): ");
         scanf("%d %d", &m, &n);
         
         printf("Enter the operation(+, -, /, *, !, ^, %%): ");
         scanf(" %c", &op);
         
         
         
         switch(op)
         {
             case '+':
                
                 printf("Enter the first operand: ");
                 scanf("%lf", &numd1);
         
                 printf("Enter the second operand: ");
                 scanf("%lf", &numd2);
                 
                 result = numd1 + numd2;
                 
                 for(int i = 0 ; i < n ; i++ )  //n represents the digit number after decimal point. so, it actually provided by dividing result by 10 n times. it gives us the appropriate decreasing. i made this for all operation results.
                 {
                     result /= 10;
                 }
                 
                 printf("%lf + %lf = ", numd1, numd2);
                 
                 for(int i = 0 ; i < (m - n - 1) ; i++ ) //prints 0 (m-n-1) times because it prints 1 0 automatically, and n digits are after decimal point. to make digits m, we should m-n-1 digits.
                 {
                     printf("0");
                 }
                 
                 printf("%.*lf", n, result);  //there will be n digits after decimal point
                 
                 printf("e%d", n); //then n will bre printed after e.
                 
                 break;
                 
             case '-':
                 
                 printf("Enter the first operand: ");
                 scanf("%lf", &numd1);
         
                 printf("Enter the second operand: ");
                 scanf("%lf", &numd2);
                 
                 result = numd1 - numd2;
                 
                 for(int i = 0 ; i < n ; i++ )
                 {
                     result /= 10;
                 }
                 
                 printf("%lf - %lf = ", numd1, numd2);
                 
                 for(int i = 0 ; i < (m - n - 1) ; i++ )
                 {
                     printf("0");
                 }
                 
                 printf("%.*lf", n, result); 
                 
                 printf("e%d", n);
                 
                 break;    
         
             case '/':
                 
                 printf("Enter the first operand: ");
                 scanf("%lf", &numd1);
         
                 printf("Enter the second operand: ");
                 scanf("%lf", &numd2);
                 
                 result = numd1 / numd2;
                 
                 for(int i = 0 ; i < n ; i++ )
                 {
                     result /= 10;
                 }
                 
                 printf("%lf / %lf = ", numd1, numd2);
                 
                 for(int i = 0 ; i < (m - n - 1) ; i++ )
                 {
                     printf("0");
                 }
                 
                 printf("%.*lf", n, result); 
                 
                 printf("e%d", n);
                 
                 break;
                 
             case '*':
                 
                 printf("Enter the first operand: ");
                 scanf("%lf", &numd1);
         
                 printf("Enter the second operand: ");
                 scanf("%lf", &numd2);
                 
                 for(int i = 0 ; i < n ; i++ )
                 {
                     result /= 10;
                 }
                 
                 printf("%lf * %lf = ", numd1, numd2);
                 
                 for(int i = 0 ; i < (m - n - 1) ; i++ )
                 {
                     printf("0");
                 }
                 
                 printf("%.*lf", n, result);  
                 
                 printf("e%d", n);
                 
                 break; 
                 
             case '%':
                 
                 printf("Enter the first operand: ");
                 scanf("%lf", &numd1);
         
                 printf("Enter the second operand: ");
                 scanf("%lf", &numd2);
                 
                 result = remainder(numd1 , numd2); //remainder() func is called. becuase % operator doesn't work with doubles
                 
                 for(int i = 0 ; i < n ; i++ )
                 {
                     result /= 10;
                 }
                 
                 printf("%lf %% %lf = ", numd1, numd2);
                 
                 for(int i = 0 ; i < (m - n - 1) ; i++ )
                 {
                     printf("0");
                 }
                 
                 printf("%.*lf", n, result);  
                 
                 printf("e%d", n);
                 
                 break;
                 
             case '!':
                 
                 printf("Enter the operand: ");
                 scanf("%lf", &numd1);
                 
                 for(int i = 0 ; i < (m - n - 1) ; i++ )
                 {
                     printf("0");
                 }
                 
                 printf("%lf! = %.*lf", numd1, n, fact(numd1)); //printf calls factorial function and print its result
                  
                 break;
                 
             case '^':
                 
                 printf("Enter the first operand: ");
                 scanf("%lf", &numd1);
         
                 printf("Enter the second operand: ");
                 scanf("%lf", &numd2);
                 
                 result = pow(numd1, numd2);
                 
                 for(int i = 0 ; i < n ; i++ )
                 {
                     result /= 10;
                 }
                 
                 printf("%lf ^ %lf = ", numd1, numd2);
                 
                 for(int i = 0 ; i < (m - n - 1) ; i++ )
                 {
                     printf("0");
                 }
                 
                 printf("%.*lf", n, result);  
                 
                 printf("e%d", n);
                 
                 break;   
                 
             default:
             
                 printf("Invalid operator.");  
                 
                              
         }
         
         
    
    }
    
    if(forsel == 'I' || forsel == 'i') // adding one option "i" to if user gives lowercase and automatically thinks lowercase of I is i.
    {
         
         printf("Enter the operation(+, -, /, *, !, ^, %%): ");
         scanf(" %c", &op);
         
         
         switch(op)
         {
             case '+':
                 
                 printf("Enter the first operand: ");
                 scanf("%d", &numi1);
         
                 printf("Enter the second operand: ");
                 scanf("%d", &numi2);
                 
                 printf("%d + %d = %d", numi1, numi2, numi1 + numi2);
                 
                 break;
                 
             case '-':
                 
                 printf("Enter the first operand: ");
                 scanf("%d", &numi1);
         
                 printf("Enter the second operand: ");
                 scanf("%d", &numi2);
                 
                 printf("%d - %d = %d", numi1, numi2, numi1 - numi2);
                 
                 break;    
         
             case '/':
                 
                 printf("Enter the first operand: ");
                 scanf("%d", &numi1);
         
                 printf("Enter the second operand: ");
                 scanf("%d", &numi2);
                 
                 printf("%d / %d = %d", numi1, numi2, numi1 / numi2);
                 
                 break;
                 
             case '*':
                 
                 printf("Enter the first operand: ");
                 scanf("%d", &numi1);
         
                 printf("Enter the second operand: ");
                 scanf("%d", &numi2);
                 
                 printf("%d * %d = %d", numi1, numi2, numi1 * numi2);
                 
                 break; 
                 
             case '%':
                 
                 printf("Enter the first operand: ");
                 scanf("%d", &numi1);
         
                 printf("Enter the second operand: ");
                 scanf("%d", &numi2);
                 
                 printf("%d %% %d = %d", numi1, numi2, numi1 % numi2);
                 
                 break;
                 
             case '!':
                 
                 printf("Enter the operand: ");
                 scanf("%d", &numi1);
                 
                 numtd = (double)(numi1); //to making possible to take num1 to an double parametered function fact(), i had to convert num1 int to double. the reason that i wrote fact() function as double parametered is that it takes also scientific format numbers and they are float. maybe you can say that why didnt you use two variables, one for float, other for int. that is because i didnt want to use more storage with one more variable
                 
                 numti = (int)fact(numtd); //because of fact is a double parametered function, i passed it double value but as the expected output is in decimal format, i casted the result of the function into integer and saved that in numti variable. 
                 
                 printf("%d! = %d", numi1, numti); //then i printed it.
                 
                 break;
                 
             case '^':
                 
                 printf("Enter the first operand: ");
                 scanf("%d", &numi1);
         
                 printf("Enter the second operand: ");
                 scanf("%d", &numi2);
                 
                 printf("%d ^ %d = %f", numi1, numi2, pow(numi1, numi2));
                 
                 break;
                 
             default:
             
                 printf("Invalid operator.");
                 
                                    
         }
         
         
    }
    
    getchar(); // to continue take character. otherwise after format decision program ends.
}



int fincalc(int ex1, int ex2, int ex3, int ass1, int ass2)
{

   int fin;
   
   fin = (ex1 + ex2 + ex3) / 3 * 0.6 + (ass1 + ass2) / 2 * 0.4;
   
   if(fin >= 60)
   {
      printf("Final Grade: %d. Passed!\n\n", fin);
   }
   
   else
   {
      printf("Final Grade: %d. Failed!\n\n", fin);
   }

}

double fact(double a)
{
   
   int i, fact = 1;
   
   for(i =1; i <= a; i++ )
   {
      fact = fact * i; 
   }  

   return fact;

}



