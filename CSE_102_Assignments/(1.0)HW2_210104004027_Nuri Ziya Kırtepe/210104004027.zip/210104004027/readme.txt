outputs of scientific format has zeros after the result, but they are worthless because of their position. 
if you multiply number with number after the "e" letter, which is also equal n, you will see result is correct.
