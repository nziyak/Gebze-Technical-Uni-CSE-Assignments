#ifndef _ZIA_H_
#define _ZIA_H_

//declaring functions will be used

int leapy(int);

double calc(char);

int fincalc(int, int, int, int, int);

double fact(double); //i made the parameter type double to save after point digits of floats. 


#endif /* _ZIA_H_ */
